<%@ Page Language="C#" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HW7 IIS Website 8081</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fff7ec;
            margin: 0;
            padding: 40px;
        }

        .card {
            max-width: 750px;
            margin: auto;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
        }

        h1 {
            color: #9a4d00;
        }

        p {
            font-size: 18px;
            line-height: 1.6;
        }

        .label {
            color: #c46a00;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>ASP.NET Server-side Page</h1>

        <p><span class="label">Name:</span> Natthaphat Sikhodchakai</p>
        <p><span class="label">Student ID:</span> 6810301024</p>

        <hr>

        <p><span class="label">Current Date and Time:</span> <%= DateTime.Now %></p>
        <p><span class="label">Machine Name:</span> <%= Environment.MachineName %></p>
        <p><span class="label">User Host Address:</span> <%= Request.UserHostAddress %></p>

        <p>This page is created for HW7 IIS Website on port 8081.</p>
        <p>It uses ASP.NET server-side commands to display dynamic information.</p>
    </div>
</body>
</html>